﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;
using System.Web.Mvc;
using System.Web.Script.Serialization;

namespace Web.PDF.Demo.Controllers
{
    public class PdfController : Controller
    {
        public class JuristicRequestParams
        {
            //Juristic Request Property
            public string DocTypeKey { get; set; }
            public string JuristicID { get; set; }
            public string Year { get; set; }
            public int Page { get; set; }
        }

        public class AuthenticationGovermentAPI
        {
            //Authentication Property : API.Egov
            public string ConsumerKey { get; set; }
            public string ConsumerSecret { get; set; }
            public string AgentID { get; set; }
            public string Token { get; set; }
        }

        public class AuthenticationResponseGovermentAPI
        {
            public string Result { get; set; }
        }

        public class ReponseData
        {
            public string ID { get; set; }
            public string FileName { get; set; }
            public string FileSize { get; set; }
            public string mimeType { get; set; }
            public string Hashes { get; set; }
            public string Result { get; set; }
        }

        public ActionResult Index()
        {
            return View();


        }


        [Route("Pdf/OpenPdf")]
        [HttpGet]
        public ActionResult OpenPdf(JuristicRequestParams request)
        {
            try
            {
                if (request.JuristicID==null || string.IsNullOrEmpty(request.JuristicID))
                {
                    throw new Exception("กรุณาระบุ หมายเลขนิติบุคคล 13 หลัก");
                }

                AuthenticationGovermentAPI auth = new AuthenticationGovermentAPI();
                auth.ConsumerKey = "";
                auth.ConsumerSecret = "";
                auth.AgentID = "";

                #region FetchToken
                JObject authJson = FetchToken(auth);
                JavaScriptSerializer serializer = new JavaScriptSerializer();
                serializer.MaxJsonLength = int.MaxValue;

                AuthenticationResponseGovermentAPI token = serializer.Deserialize<AuthenticationResponseGovermentAPI>(authJson.ToString());
                auth.Token = token.Result;
                #endregion



                #region Fetch
                JObject json = FetchJuristics(request, auth);
                JavaScriptSerializer serializer2 = new JavaScriptSerializer();
                serializer2.MaxJsonLength = int.MaxValue;
                ReponseData obj = serializer2.Deserialize<ReponseData>(json.ToString());
                #endregion

                if (obj != null)
                {
                    if (!string.IsNullOrEmpty(obj.Result))
                    {


                        //สามารถ Download ได้ 
                        byte[] fileByteArray = Base64urlStringToByte(obj.Result);
                        if (fileByteArray.Length <= 0)
                        {
                            throw new Exception("ไม่พบไฟล์");
                        }

                        using (MemoryStream ms = new MemoryStream(fileByteArray))
                        {
                            string contentType = "application/pdf";
                            string filename = HttpUtility.UrlEncode(obj.FileName, System.Text.Encoding.UTF8);
                            string header = string.Format("inline;filename={0}", filename);

                            Response.ContentType = contentType;
                            Response.AddHeader("content-disposition", header);
                            Response.Buffer = true;
                            ms.WriteTo(Response.OutputStream);
                            Response.End();
                            return new FileStreamResult(ms, "application/pdf");
                        }

                    }
                    throw new Exception("");
                }
                throw new Exception("พบข้อผิดพลาด");
            }
            catch (Exception ex)
            {
                ViewBag.ErrorMsg = ex.Message;
            }
            return View();
        }



        public static JObject FetchToken(AuthenticationGovermentAPI auth)
        {
            try
            {
                JavaScriptSerializer serializer = new JavaScriptSerializer();
                serializer.MaxJsonLength = int.MaxValue;

                #region NewCall
                try
                {
                    string url = "https://api.egov.go.th/ws/auth/validate";
                    //Add Parameters
                    url += "?ConsumerSecret=" + auth.ConsumerSecret + "&AgentID=" + auth.AgentID;


                    HttpWebRequest httpWebRequest = System.Net.WebRequest.Create(url) as HttpWebRequest;
                    httpWebRequest.Headers.Add("Consumer-Key", auth.ConsumerKey);

                    using (var twitpicResponse = (HttpWebResponse)httpWebRequest.GetResponse())
                    {
                        if (twitpicResponse.StatusCode.ToString() == "OK" || twitpicResponse.StatusCode.ToString() == "Success")
                        {
                            using (var reader = new StreamReader(twitpicResponse.GetResponseStream()))
                            {
                                var objText = reader.ReadToEnd();
                                dynamic json = JsonConvert.DeserializeObject(objText);
                                return json;
                                //200
                                //204
                                //400
                                //500
                            }
                        }
                        else
                        {
                            throw new Exception(twitpicResponse.StatusDescription);
                        }


                    }
                }
                catch (WebException we)
                {
                    var response = ((HttpWebResponse)we.Response);
                    var someheader = response.Headers["X-API-ERROR"];
                    // check header
                    var content = response.GetResponseStream();
                    // check the content if needed 

                    if (we.Status == WebExceptionStatus.ProtocolError)
                    {
                        // protocol errors find the statuscode in the Response
                        // the enum statuscode can be cast to an int.
                        int code = (int)((HttpWebResponse)we.Response).StatusCode;
                        // do what ever you want to store and return to your callers
                    }

                    var reader = new StreamReader(we.Response.GetResponseStream());
                    var content2 = reader.ReadToEnd();

                    throw new Exception(content2);

                    //var wRespStatusCode = ((HttpWebResponse)we.Response).StatusCode;
                    //throw new Exception(we.Message);
                }
                #endregion

                //return model;
            }
            catch (Exception ex)
            {
                //EXCEPTION
                throw new Exception(ex.Message);
                //return new JuristicIndexViewModels() { };
            }

        }

        public static JObject FetchJuristics(JuristicRequestParams request, AuthenticationGovermentAPI auth)
        {
            try
            {
                Dictionary<string, string> args = new Dictionary<string, string>();
                args.Add("JuristicID", request.JuristicID);

                JavaScriptSerializer serializer = new JavaScriptSerializer();
                serializer.MaxJsonLength = int.MaxValue;

                #region NewCall
                try
                {
                    string url = "https://api.egov.go.th/ws/dbd/v2/juristic/certificate/signed";

                    //Add Parameters
                    url += "?JuristicID=" + request.JuristicID;

                    HttpWebRequest httpWebRequest = System.Net.WebRequest.Create(url) as HttpWebRequest;
                    httpWebRequest.Headers.Add("Consumer-Key", auth.ConsumerKey);
                    httpWebRequest.Headers.Add("Token", auth.Token);

                    using (var twitpicResponse = (HttpWebResponse)httpWebRequest.GetResponse())
                    {
                        if (twitpicResponse.StatusCode.ToString() == "OK" || twitpicResponse.StatusCode.ToString() == "Success")
                        {
                            using (var reader = new StreamReader(twitpicResponse.GetResponseStream()))
                            {
                                var objText = reader.ReadToEnd();
                                dynamic json = JsonConvert.DeserializeObject(objText);
                                return json;
                                //200
                                //204
                                //400
                                //500
                            }
                        }
                        else
                        {
                            throw new Exception(twitpicResponse.StatusDescription);
                        }


                    }
                }
                catch (WebException we)
                {
                    var response = ((HttpWebResponse)we.Response);
                    var someheader = response.Headers["X-API-ERROR"];
                    // check header
                    var content = response.GetResponseStream();
                    // check the content if needed 

                    if (we.Status == WebExceptionStatus.ProtocolError)
                    {
                        // protocol errors find the statuscode in the Response
                        // the enum statuscode can be cast to an int.
                        int code = (int)((HttpWebResponse)we.Response).StatusCode;
                        // do what ever you want to store and return to your callers
                    }

                    var reader = new StreamReader(we.Response.GetResponseStream());
                    var content2 = reader.ReadToEnd();

                    throw new Exception(content2);

                    //var wRespStatusCode = ((HttpWebResponse)we.Response).StatusCode;
                    //throw new Exception(we.Message);
                }
                #endregion

                //return model;
            }
            catch (Exception ex)
            {
                //EXCEPTION
                throw new Exception(ex.Message);
                //return new JuristicIndexViewModels() { };
            }

        }


        #region Helper
        public byte[] Base64urlStringToByte(string base64ForUrlInput)
        {
            int padChars = (base64ForUrlInput.Length % 4) == 0 ? 0 : (4 - (base64ForUrlInput.Length % 4));
            StringBuilder result = new StringBuilder(base64ForUrlInput, base64ForUrlInput.Length + padChars);
            result.Append(String.Empty.PadRight(padChars, '='));
            result.Replace('-', '+');
            result.Replace('_', '/');
            return Convert.FromBase64String(result.ToString());
        }
        #endregion
    }
}